#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iomanip>

using namespace std;

// This class handles all the heavy lifting for reading grocery items and tracking frequencies
class GroceryTracker {
private:
    // A map is perfect here: string is the item name, int is how many times it was bought
    map<string, int> itemFrequencyMap;
    
    // File names we need to deal with
    string inputFileName = "CS210_Project_Three_Input_File.txt";
    string outputFileName = "frequency.dat";

    // Helper method to read the raw input data and write out the frequency backup file
    void LoadDataAndBackup() {
        ifstream inputFile(inputFileName);
        
        // Safety check just in case the input file isn't in the same directory
        if (!inputFile.is_open()) {
            cout << "Oops! Couldn't open the input file: " << inputFileName << endl;
            return;
        }

        string item;
        // Read the file word by word (or item by item)
        while (inputFile >> item) {
            // If the item isn't in the map yet, C++ adds it automatically with a default value of 0 and increments it
            itemFrequencyMap[item]++;
        }
        inputFile.close();

        // Time to write out the backup file (frequency.dat) right at startup like the prompt asked
        ofstream outputFile(outputFileName);
        if (!outputFile.is_open()) {
            cout << "Oops! Couldn't create the backup file: " << outputFileName << endl;
            return;
        }

        // Loop through our map and write each "Item Count" pair to frequency.dat
        for (const auto& pair : itemFrequencyMap) {
            outputFile << pair.first << " " << pair.second << endl;
        }
        outputFile.close();
    }

public:
    // When a GroceryTracker object is created, it immediately loads the data and creates the backup
    GroceryTracker() {
        LoadDataAndBackup();
    }

    // Option 1: Find out how many times a single specific item was bought
    void SearchItemFrequency() {
        string searchItem;
        cout << "Enter the item you wish to look for: ";
        cin >> searchItem;

        // Check if the item actually exists in our map
        if (itemFrequencyMap.find(searchItem) != itemFrequencyMap.end()) {
            cout << endl << searchItem << " was purchased " << itemFrequencyMap[searchItem] << " time(s).\n" << endl;
        } else {
            cout << endl << "Item \"" << searchItem << "\" was not found in today's sales records.\n" << endl;
        }
    }

    // Option 2: Print out the full list of items alongside their purchase numbers
    void PrintFrequencyList() {
        cout << "\n--- Item Purchase Frequencies ---\n";
        for (const auto& pair : itemFrequencyMap) {
            cout << pair.first << " " << pair.second << endl;
        }
        cout << "----------------------------------\n\n";
    }

    // Option 3: Display a nice text-based histogram with asterisks
    void PrintHistogram() {
        cout << "\n--- Purchase Frequency Histogram ---\n";
        for (const auto& pair : itemFrequencyMap) {
            // Clean formatting: left-align the item name in a 12-character column
            cout << setw(12) << left << pair.first << " ";
            
            // Print one asterisk for every count in frequency
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
        cout << "------------------------------------\n\n";
    }
};

// Quick helper function to keep the main menu neat and clean
void DisplayMenu() {
    cout << "=== Corner Grocer Item Tracking System ===\n";
    cout << "1. Look up frequency of a specific item\n";
    cout << "2. Display frequency list of all items\n";
    cout << "3. Display text-based histogram of all items\n";
    cout << "4. Exit program\n";
    cout << "Enter your choice (1-4): ";
}

int main() {
    // Instantiating this object handles reading the input file and building frequency.dat right away
    GroceryTracker tracker;
    int choice = 0;

    // Keep the menu running until the user picks option 4
    do {
        DisplayMenu();
        
        // Input validation: handle bad inputs like typing letters instead of numbers
        if (!(cin >> choice)) {
            cout << "Invalid input! Please enter a number between 1 and 4.\n\n";
            cin.clear();            // Reset the error state of cin
            cin.ignore(10000, '\n'); // Clear out bad characters in the input buffer
            continue;
        }

        switch (choice) {
            case 1:
                tracker.SearchItemFrequency();
                break;
            case 2:
                tracker.PrintFrequencyList();
                break;
            case 3:
                tracker.PrintHistogram();
                break;
            case 4:
                cout << "Exiting program. Have a great day!\n";
                break;
            default:
                cout << "Invalid choice! Please select a valid option (1-4).\n\n";
                break;
        }
    } while (choice != 4);

    return 0;
}